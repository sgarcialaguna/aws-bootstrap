#!/bin/bash -xe
docker stop 061199822233.dkr.ecr.eu-central-1.amazonaws.com/aws_bootstrap:latest || true