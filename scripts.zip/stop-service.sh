#!/bin/bash -xe
docker stop aws_bootstrap || true